// pide por pantalla 1 numero con boton, metemos el 20 y nos dice en un alert el primer numero primo mayor que el introducido

// con do while y while
function primos() {
  var numero=document.getElementById("num").value;
 
  var fin = 0;
  var division = 1;
  var resultado = 0;
  var resultado2 = 0;
  do{
      numero++;
      division = 1;
      resultado = 0;
      resultado2 = 0;
      while(division<=numero){
          resultado = numero%division;
          if(resultado == 0){
              resultado2=resultado2 + 1;
          }
          division++;
      }
      if(resultado2 == 2){
          alert("El siguiente numero primo es "+numero);
          fin = 1;
      }
      
  }while(fin == 0)
}


/* con while solo

function primos() {
var numero=document.getElementById("num").value;
numero=numero+1;
var salida=false;
var indice=1;

while (salida===0){
  indice++;
  while(numero%indice===0){
    if(numero==indice){
      salida=true;
      break;
    }else{
      indice=1;
      numero++;
      break;
    }
  }
}

alert("El siguiente numero primo es "+numero);
}

*/


/*solucion profesor

function primos() {
    var inputNumber = document.getElementById("num").value;
    if (isNaN(Number(inputNumber))) {
        alert("No me trolees!!");
        return;
    }
 
    while (!esPrimo(inputNumber)) {
        inputNumber++;
    }
    alert("Siguiente primo: " + inputNumber);
}
 
function esPrimo(numero){
    for (var i = 2; i < numero; i++) {
        if (numero%i==0){
            return false;
        }
    };
    return true;
}









*/

