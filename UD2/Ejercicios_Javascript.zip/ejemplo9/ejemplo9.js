//numero primo hasta 23

function primos() {
/*
  
  division = 1;
  resultado = 0;
  resultado2 = 0;
  
  for(var i=0;i<=23;i++){
      division = 1;
      resultado = 0;
      resultado2 = 0;
      while(division<=i){
          resultado = i%division;
          if(resultado == 0){
              resultado2=resultado2 + 1;
          }
  
          division++;
      }
      
      if(resultado2 == 2){
          document.write(i+" es primo.<br>");
      }
      
  }

}*/


/*------------------------------------------------
function esPrimo(numero){
    for (var i = 2; i < numero; i++) {
        if (numero%i==0){
            return false;
        }
    };
    return true;
}


function mostrarprimos(){
    for(var i=2;i<=23;i++){

        if (esPrimo(i)){
        document.write(i);
        document.write("||");

        }

    }

}

function mostrarprimosalreves(){
    for(var i=23;i>=2;i--){
        if (esPrimo(i)){
        document.write(i);
        document.write("||");
        }

    }

}
---------------------------------------------------------*/

for(var i=23;i>=2;i--){
  division = 1;
  resultado = 0;
  resultado2 = 0;
  while(division<=i){
      resultado = i%division;
      if(resultado == 0){
          resultado2=resultado2 + 1;
      }

      division++;
  }
  
  if(resultado2 == 2){
      document.write(i+" es primo.<br>");
  }
  
}

}
  


    
  













