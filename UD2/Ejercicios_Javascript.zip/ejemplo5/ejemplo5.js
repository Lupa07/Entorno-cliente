

function impares() {
  var numero = 1;


  while (numero <= 20) {
    if (numero % 2 != 0) {

      console.log(numero);
    }

    numero++;
  }
}

function numeroImpar() {
  var cadena = " ";
  var impares = 1;
  var max = 20;

  while (impares <= 20) {
    if (impares % 2 != 0) {
      console.log(impares);
      cadena = cadena + " " + impares;
    }
    impares++;
  }

  document.getElementById("p3").innerHTML = cadena;

}





