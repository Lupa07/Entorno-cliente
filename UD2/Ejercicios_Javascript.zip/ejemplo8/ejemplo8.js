//tabla del uno al 10

function tabla() {

  for(i=0;i<10;i++){
    
    document.write("el valor de la variable es "+i+"<br>");
  }


  for(i=1;i<=10;i++){
    document.write("<br>");
    document.write("<b>Tabla del "+i+"</b><br>");
    document.write("---------------<br>");
    for(j=1;j<=10;j++){
      document.write("<span>"+i+" x "+j+" = "+(j*i)+"</span><br>");
    }
  }

  for(i=1;i<=10;i++){
    document.write("<br>");
    document.write("<br>");
    document.write("<b>Tabla del "+i+"</b><br>");
   
    document.write("---------------<br>");
    for(j=1;j<=10;j++){
      document.write(i+" x "+j+" = "+(j*i)+" || ");
    }
  }

  



    
  }













