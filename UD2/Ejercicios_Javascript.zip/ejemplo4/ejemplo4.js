

function nota(){
var notaAlumno=prompt("Introduce la nota");


switch (Number(notaAlumno)){
  
  case 0:case 1:case 2:case 3:case 4:
     alert("suspenso")
    break;
  case 5:case 6:
     alert("aprobado")
    break;
  case 7:case 8:
    alert("notable")
    break;
  case 9:case 10:
    alert("Sobresaliente")
    break;
  default: alert ("Nota erronea")
    
}


}