// pide por pantalla 1 numero con boton, y lo muestra en vertical

function vertical() {

var numero=25478;
while (numero>0){
  var resto=numero%10;
  numero=parseInt (numero/10);
  console.log(resto);

}

}


function vertical2(){
  var numero=document.getElementById("num2").value;
  var longitud= numero.toString().length;
  var contador=1;
  while(contador<=longitud){
    numero%10;
    numero/10;
  }
  var todos=numero/10;
  
 
  alert(longitud);
  alert(todos);
  alert(numero%10);

}









