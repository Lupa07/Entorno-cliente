//Realiza un script que pida cadenas de texto y las concatene 
//usando el carácter “-” cada vez que el usuario pulse “Seguir”
// y hasta que se pulse “Cancelar”. Al salir con “Cancelar” 
//deben mostrarse todas las cadenas concatenadas.

var cadena="";

function encadenar(){
do {
var palabra=prompt("introduce una palabra");

var confirmar=confirm("¿quiere seguir?");

if (confirmar==true){
    cadena=cadena+palabra+"-";
}else{
    cadena=cadena+palabra;
}


}while(confirmar==true);

alert(cadena);
}





