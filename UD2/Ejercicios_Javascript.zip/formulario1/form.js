// el numero que metemos en el formulario tiene que estar entre 5 y 10
// JAVASCRIPT FORM VALIDATION


function validar(){

    var numero=document.getElementById("telefono").value;
    if(numero<2 || numero>6){
        alert("solo numeros entre 2 y 6")
    }

    


}


function navegador(){
    var miNavegador=window.navigator.userAgent;
       console.log(miNavegador);

       if(miNavegador.indexOf("Chrome")>-1){
           document.write("chrome");
       }else if (miNavegador.indexOf("Firefox")>-1){
        document.write("firefox");
       }else{
           alert("a saber que navegador usas");
       }
}

function cookies(){
    var misCookies=document.cookie;
    
}