

function division(){

var dividendo=prompt("Introduce el dividendo: ");
var divisor=prompt("Introdice el divisor");
var resultado;

divisor!=0 ? resultado=dividendo/divisor:
  alert("No es posible la división por cero");
  alert("El resultado es: "+resultado);

}


function anyo(){
  var anyo=prompt("introduce año");


  if ((anyo%400 ==0) || (anyo%4==0 && anyo%100!=0)){
    alert("es bisiesto");
}else{
  alert ("no es bisiesto");
}

}