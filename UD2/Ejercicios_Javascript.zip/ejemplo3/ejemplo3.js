

function hacer(){
var edad=document.getElementById("edad").value;


if (edad<18 && !isNaN(edad)){
  alert("es menor de edad ");
}else if (edad>=18 && !isNaN(edad)){
  alert("es mayor de edad");
}else{
  alert("no ha metido un numero");
}


}